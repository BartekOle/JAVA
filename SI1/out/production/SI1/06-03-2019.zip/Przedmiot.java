public class Przedmiot {
    int index;
    int wartosc;
    int waga;
    int idmiasta;

    public Przedmiot(int index, int wartosc, int waga, int idmiasta)
    {
        this.index = index;
        this.wartosc = wartosc;
        this.waga = waga;
        this.idmiasta = idmiasta;

    }
}
