public class Miasto {
    int index;
    double x;
    double y;

    public Miasto(int index, double x, double y)
    {
        this.index = index;
        this.x = x;
        this.y = y;
    }

    public double odleglosc(Miasto m1, Miasto m2)
    {
       double odl =  Math.sqrt(Math.pow(m2.x - m1.x, 2) + Math.pow(m2.y - m1.y, 2));
        return odl;
    }
}


